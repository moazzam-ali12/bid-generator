from __future__ import annotations

import json
import os
import asyncio
from typing import List, Dict, Any
from datetime import date

from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import Response
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

from extract import (
    IngestedDoc,
    extract_text_from_pdf,
    extract_text_from_docx,
    keyword_window,
    build_context,
    KEYWORDS_PROMPT_1,
    KEYWORDS_PROMPT_2,
    KEYWORDS_PROMPT_3,
)
from prompts import prompt_1_table1, prompt_2_table2, prompt_3_tables3_4_5
from openai_client import OpenAIClient, OpenAIConfig
from excel_writer import build_workbook

load_dotenv()

app = FastAPI(title="Northlake OpenAI Bid Excel Generator", version="0.1.0")

# 🔧 CORS Middleware - Required for frontend to communicate with API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with specific domains
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _cfg() -> OpenAIConfig:
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    base_url = os.getenv("OPENAI_BASE_URL", "").strip()
    model = os.getenv("OPENAI_MODEL", "").strip()
    if not api_key or not base_url or not model:
        raise RuntimeError("Missing OPENAI_API_KEY, OPENAI_BASE_URL, or OPENAI_MODEL in environment/.env")

    temperature = float(os.getenv("TEMPERATURE", "0.1"))
    max_tokens = int(os.getenv("MAX_TOKENS", "4000"))
    return OpenAIConfig(
        api_key=api_key,
        base_url=base_url,
        model=model,
        temperature=temperature,
        max_tokens=max_tokens,
        timeout_s=600.0,
    )


def _ingest(files: List[UploadFile]) -> List[IngestedDoc]:
    docs: List[IngestedDoc] = []
    for f in files:
        data = f.file.read()
        name = f.filename or "uploaded"
        lower = name.lower()
        if lower.endswith(".pdf"):
            text = extract_text_from_pdf(data)
        elif lower.endswith(".docx"):
            text = extract_text_from_docx(data)
        else:
            # best effort: treat as utf-8 text
            try:
                text = data.decode("utf-8", errors="ignore")
            except Exception:
                text = ""
        docs.append(IngestedDoc(filename=name, text=text))
    return docs


def _maybe_filter(docs: List[IngestedDoc], keywords: List[str], disable: bool) -> List[IngestedDoc]:
    if disable:
        return docs
    out = []
    for d in docs:
        filtered = keyword_window(d.text, keywords=keywords, window_lines=4, max_chars=60_000)
        # fall back to a modest prefix if keyword filtering finds nothing
        if not filtered.strip():
            filtered = d.text[:30_000]
        out.append(IngestedDoc(filename=d.filename, text=filtered))
    return out


async def _parse_json_or_retry_async(
    client: OpenAIClient, 
    system: str, 
    user: str, 
    retries: int = 1
) -> Dict[str, Any]:
    """Async version of JSON parsing with retry"""
    last = None
    for attempt in range(retries + 1):
        # Run the synchronous client call in a thread pool
        raw = await asyncio.to_thread(client.chat_json, system=system, user=user)
        last = raw
        try:
            return json.loads(raw)
        except Exception:
            if attempt >= retries:
                raise HTTPException(
                    status_code=502,
                    detail=f"Model did not return valid JSON. Last response: {raw[:2000]}"
                )
            user = (
                "Your previous response was not valid JSON.\n"
                "Return ONLY valid JSON that matches the schema. No markdown. No extra keys.\n\n"
                + user
            )
    raise HTTPException(
        status_code=502,
        detail=f"Model did not return valid JSON. Last response: {str(last)[:2000]}"
    )


@app.get("/")
def root():
    """Root endpoint"""
    return {
        "message": "Northlake Bid Excel Generator API",
        "version": "0.1.0",
        "docs": "/docs",
        "health": "/health"
    }


@app.get("/health")
def health():
    return {"ok": True, "status": "running"}


@app.post("/generate-bid-excel")
async def generate_bid_excel(
    files: List[UploadFile] = File(...),
    project_name: str = Form("Northlake 7-Eleven"),
):
    try:
        cfg = _cfg()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    disable_filter = os.getenv("DISABLE_KEYWORD_FILTER", "false").strip().lower() in ("1", "true", "yes", "y")

    # Ingest documents (synchronous, but fast)
    docs_full = _ingest(files)
    doc_list = [d.filename for d in docs_full]

    client = OpenAIClient(cfg)

    # Prepare contexts for all three prompts
    docs1 = _maybe_filter(docs_full, KEYWORDS_PROMPT_1, disable_filter)
    ctx1 = build_context(docs1)
    p1 = prompt_1_table1(project_name, doc_list)
    user1 = p1["user"] + "\n\nDOCUMENT CONTEXT:\n" + ctx1

    docs2 = _maybe_filter(docs_full, KEYWORDS_PROMPT_2, disable_filter)
    ctx2 = build_context(docs2)
    p2 = prompt_2_table2(project_name, doc_list)
    user2 = p2["user"] + "\n\nDOCUMENT CONTEXT:\n" + ctx2

    docs3 = _maybe_filter(docs_full, KEYWORDS_PROMPT_3, disable_filter)
    ctx3 = build_context(docs3)
    p3 = prompt_3_tables3_4_5(project_name, doc_list)
    user3 = p3["user"] + "\n\nDOCUMENT CONTEXT:\n" + ctx3

    # 🚀 KEY OPTIMIZATION: Run all three API calls in parallel
    print("Starting parallel API calls...")
    out1, out2, out3 = await asyncio.gather(
        _parse_json_or_retry_async(client, p1["system"], user1, retries=1),
        _parse_json_or_retry_async(client, p2["system"], user2, retries=1),
        _parse_json_or_retry_async(client, p3["system"], user3, retries=1),
    )
    print("All API calls completed!")

    # Generate Excel file
    xlsx_bytes = build_workbook(out1, out2, out3)

    filename = f"{project_name.replace(' ', '_')}_Bid_Tables.xlsx"
    return Response(
        content=xlsx_bytes,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )