\
from __future__ import annotations

from typing import Dict, List


CREATED_BY_LINE = "Herman G. Lehman IV, PE, Atlas Technical Consultants; 210-287-1300"


def _common_rules_json_only() -> str:
    return (
        "OUTPUT RULES (MANDATORY):\n"
        "1) Return STRICT JSON only. No markdown. No backticks. No commentary.\n"
        "2) Use the exact JSON schema requested.\n"
        "3) If a value is not explicitly found in the provided documents, write \"NOT SPECIFIED\".\n"
        "4) Never invent drawing numbers, report numbers, quantities, or requirements.\n"
        "5) For every row, include a 'sources' field listing where you found it, e.g. "
        "\"Geotech.pdf p.17\" or \"Civil.pdf sheet 13\". If not found: \"NOT FOUND\".\n"
        "6) If two provided documents conflict, set the field value to \"CONFLICT\" and include both sources.\n"
    )


def prompt_1_table1(project_name: str, doc_list: List[str]) -> Dict:
    """
    Prompt 1: Table 1 (Geotech field testing requirements + addendum notes)
    """
    user = f"""
You are generating Table 1 for a CMT / Special Inspection proposal.

Project: {project_name}

Documents provided (filenames): {", ".join(doc_list)}

Task:
Create "Table 1 – Field Testing Requirements (Geotech + Addendum)" in Excel-friendly form.

Use the geotechnical report as the primary source and the geotech addendum as changes.
The table must cover these construction elements as rows (left-most category column):
- Pavement Subgrade
- General Site Fill
- Building Subgrade
- Moisture Conditioned Soil
- Utility Backfill

For each row, populate these columns:
- Construction Element
- Material Type
- Max Loose Thickness
- Compaction Requirements
- Moisture Content Tolerance
- Plasticity Requirements
- Special Testing Notes
- Addendum Notes
- sources

Addendum Notes:
- summarize ONLY what changed in the addendum compared to the base geotech report.
- if the addendum does not address a row, write "No addendum changes".

Include a heading metadata block (not a separate table) in JSON:
- generated_date (YYYY-MM-DD)
- created_by (use exactly this line): {CREATED_BY_LINE}

{_common_rules_json_only()}

JSON SCHEMA (must match exactly):
{{
  "meta": {{
    "project": "{project_name}",
    "generated_date": "YYYY-MM-DD",
    "created_by": "{CREATED_BY_LINE}"
  }},
  "table1": {{
    "title": "Table 1 – Field Testing Requirements (Geotech + Addendum)",
    "columns": [
      "Construction Element",
      "Material Type",
      "Max Loose Thickness",
      "Compaction Requirements",
      "Moisture Content Tolerance",
      "Plasticity Requirements",
      "Special Testing Notes",
      "Addendum Notes",
      "sources"
    ],
    "rows": [
      {{
        "Construction Element": "",
        "Material Type": "",
        "Max Loose Thickness": "",
        "Compaction Requirements": "",
        "Moisture Content Tolerance": "",
        "Plasticity Requirements": "",
        "Special Testing Notes": "",
        "Addendum Notes": "",
        "sources": [""]
      }}
    ]
  }},
  "assumptions_or_gaps": [""]
}}
""".strip()

    return {
        "system": "You are a meticulous construction document analyst. You extract only what is explicitly stated.",
        "user": user,
    }


def prompt_2_table2(project_name: str, doc_list: List[str]) -> Dict:
    """
    Prompt 2: Table 2 (Concrete)
    """
    user = f"""
You are generating Table 2 for a CMT / Special Inspection proposal.

Project: {project_name}

Documents provided (filenames): {", ".join(doc_list)}

Task:
Create "Table 2 – Concrete Summary" in Excel-friendly form.

Tabulate ALL concrete items you can find, including (but not limited to):
- heavy-duty pavement, standard-duty pavement, tank slab, sidewalks, building slab-on-grade,
  dumpster pad, grade beams/footings, piers (if any), curbs (if specified)

For each row (one concrete element/type), populate:
- Element / Location
- Thickness
- Total SF (or LF or CY basis)  (if not provided, use "NOT SPECIFIED" - do NOT guess)
- Concrete Yards (CY) (if not provided, "NOT SPECIFIED")
- Cylinders (count) (if not provided, "NOT SPECIFIED")
- f'c (psi)
- Testing Frequency
- Max Temp (°F)
- Air Content
- Slump (in)
- Notes / Mix Notes
- sources

Include a heading metadata block in JSON:
- generated_date (YYYY-MM-DD)
- created_by: {CREATED_BY_LINE}

{_common_rules_json_only()}

JSON SCHEMA (must match exactly):
{{
  "meta": {{
    "project": "{project_name}",
    "generated_date": "YYYY-MM-DD",
    "created_by": "{CREATED_BY_LINE}"
  }},
  "table2": {{
    "title": "Table 2 – Concrete Summary",
    "columns": [
      "Element / Location",
      "Thickness",
      "Total SF (or LF/CY basis)",
      "Concrete Yards (CY)",
      "Cylinders (count)",
      "f'c (psi)",
      "Testing Frequency",
      "Max Temp (°F)",
      "Air Content",
      "Slump (in)",
      "Notes / Mix Notes",
      "sources"
    ],
    "rows": [
      {{
        "Element / Location": "",
        "Thickness": "",
        "Total SF (or LF/CY basis)": "",
        "Concrete Yards (CY)": "",
        "Cylinders (count)": "",
        "f'c (psi)": "",
        "Testing Frequency": "",
        "Max Temp (°F)": "",
        "Air Content": "",
        "Slump (in)": "",
        "Notes / Mix Notes": "",
        "sources": [""]
      }}
    ]
  }},
  "assumptions_or_gaps": [""]
}}
""".strip()

    return {
        "system": "You are a meticulous construction document analyst. You extract only what is explicitly stated.",
        "user": user,
    }


def prompt_3_tables3_4_5(project_name: str, doc_list: List[str]) -> Dict:
    """
    Prompt 3: Tables 3, 4, 5 (Rebar + Special inspections + SIP connections)
    """
    user = f"""
You are generating Tables 3, 4, and 5 for a CMT / Special Inspection proposal.

Project: {project_name}

Documents provided (filenames): {", ".join(doc_list)}

Task A (Table 3 – Reinforcement Summary):
Tabulate rebar size, configuration, spacing/dimensions, and notes for:
- pavement
- foundations / grade beams
- footings
- piers
- sidewalks
- slab-on-grade
- curbs/ramps
- any other reinforced concrete elements shown

Columns:
- Location / Element
- Bar Size
- Configuration
- Spacing / Dimensions
- Notes / Reference
- sources

Task B (Table 4 – Structural & Fire Protection Summary):
Confirm and report:
- Cold-Formed Metal Framing: Yes/No and linear feet of wall framing (ONLY if explicit; otherwise NOT SPECIFIED)
- Structural steel bolting: Yes/No and how many discrete steel pieces/members are shown (ONLY if explicit; otherwise NOT SPECIFIED)
- Spray-Applied Fire Protection (SFRM): Yes/No and depth requirements
- CJP welds: Yes/No
- PJP welds: Yes/No
- Largest Fillet Weld: size
Include a brief explanation for each item and list sources.

Task C (Table 5 – SIP Panel Connection Inspection Requirements):
Look through any SIP plans/specs provided and summarize connection inspection requirements.
If SIP plans are not present in the provided documents, clearly say so and return "NOT SPECIFIED" for details.

Include a heading metadata block in JSON:
- generated_date (YYYY-MM-DD)
- created_by: {CREATED_BY_LINE}

{_common_rules_json_only()}

JSON SCHEMA (must match exactly):
{{
  "meta": {{
    "project": "{project_name}",
    "generated_date": "YYYY-MM-DD",
    "created_by": "{CREATED_BY_LINE}"
  }},
  "table3": {{
    "title": "Table 3 – Reinforcement Summary",
    "columns": [
      "Location / Element",
      "Bar Size",
      "Configuration",
      "Spacing / Dimensions",
      "Notes / Reference",
      "sources"
    ],
    "rows": [
      {{
        "Location / Element": "",
        "Bar Size": "",
        "Configuration": "",
        "Spacing / Dimensions": "",
        "Notes / Reference": "",
        "sources": [""]
      }}
    ]
  }},
  "table4": {{
    "title": "Table 4 – Structural & Fire Protection Summary",
    "columns": [
      "Item",
      "Answer",
      "Details",
      "sources"
    ],
    "rows": [
      {{
        "Item": "Cold-Formed Metal Framing (CFMF)",
        "Answer": "",
        "Details": "",
        "sources": [""]
      }}
    ]
  }},
  "table5": {{
    "title": "Table 5 – SIP Panel Connection Inspection Requirements",
    "columns": [
      "Connection / Topic",
      "Requirement",
      "Acceptance Criteria / Frequency",
      "sources"
    ],
    "rows": [
      {{
        "Connection / Topic": "",
        "Requirement": "",
        "Acceptance Criteria / Frequency": "",
        "sources": [""]
      }}
    ]
  }},
  "assumptions_or_gaps": [""]
}}
""".strip()

    return {
        "system": "You are a meticulous construction document analyst. You extract only what is explicitly stated.",
        "user": user,
    }
